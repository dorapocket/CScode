#ifndef __STR__
#define __STR__
char ** split(char *string,char * delimiters,int *num);
char * trim(char *str);
int doOpration(int argc,char ** argv);
#endif