#ifndef a_c
#define a_c
int BLOCK_NUMS=1024;
int BLOCK_SIZE=1024;
#endif
